package scripts;

import java.io.IOException;

import org.testng.annotations.Test;

import generic.OpenCloseclass;
import generic.ReadingData;
import pom.Homepage;

public class OpeningLoginPage extends OpenCloseclass{

	@Test
	public void openLoginPage() throws IOException {
		
		Homepage homepage = new Homepage(driver);
		homepage.clickonloginlink();
		String expectedtitle = ReadingData.getdata("Sheet1", 0, 0);
		String expectedurl = ReadingData.getdata("Sheet1", 0, 1);
		homepage.checktitleofloginpage(expectedtitle);
		homepage.checkurlofloginpage(expectedurl);
		
	}
	
}

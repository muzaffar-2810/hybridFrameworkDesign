package generic;

public interface Constants 
{
  String urlofapplication = "http://127.0.0.1:5000/home";
  
  String excelsheetaddress = "C:\\Users\\Muzaffar Ahmed\\Desktop\\Eclipse2\\hybridFrameworkDesign\\driverexecutalbes\\mydata.xlsx";
  
  String chromekey = "webdriver.chrome.driver";
  
  String chromevalue = "C:\\Users\\Muzaffar Ahmed\\Desktop\\Eclipse2\\hybridFrameworkDesign\\chromedriver.exe";
  
  
}

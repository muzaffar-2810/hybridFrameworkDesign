package pom;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import generic.Verificationclass;

public class Registerpage extends Verificationclass
{	
		// find the webelements. 
		@FindBy(xpath = "//a[text()='Register']")
		private WebElement registerlink;
			
	public Registerpage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
  
	
	public void clickonregisterlink() {
		registerlink.click();
	}
	
	public void checktitleofregisterpage(String expectedtitle) throws IOException {
		//this function is derived from Verificationclass class
		verifyalltitles(expectedtitle);
	}
	
	
	public void checkurlofregisterpage(String expectedurl) throws IOException {
		//this function is derived from Verificationclass class
		verifyallurls(expectedurl);
	}
}

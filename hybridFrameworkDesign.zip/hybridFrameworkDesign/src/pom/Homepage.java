package pom;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import generic.Verificationclass;

public class Homepage extends Verificationclass
{	
	// find the webelements. 
	@FindBy(xpath = "//a[text()='Login']")
	private WebElement loginlink;
			
	public Homepage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public void clickonloginlink() {
		loginlink.click();
	}
	
	public void checktitleofloginpage(String expectedtitle) throws IOException {
		//this function is derived from Verificationclass class
		verifyalltitles(expectedtitle);
	}
	
	
	public void checkurlofloginpage(String expectedurl) throws IOException {
		//this function is derived from Verificationclass class
		verifyallurls(expectedurl);
	}
}

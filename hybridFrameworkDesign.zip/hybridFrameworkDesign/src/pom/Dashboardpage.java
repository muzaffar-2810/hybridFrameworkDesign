package pom;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import generic.Verificationclass;

public class Dashboardpage extends Verificationclass
{	
		// find the webelements. 
		@FindBy(xpath = "//a[text()='Dashboard']")
		private WebElement dashboardlink;
			
	public Dashboardpage(WebDriver driver){
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
  
	
	public void clickondashboardlink() {
		dashboardlink.click();
	}
	
	public void checktitleofdashboardpage(String expectedtitle) throws IOException {
		//this function is derived from Verificationclass class
		verifyalltitles(expectedtitle);
	}
	
	
	public void checkurlofdashboardpage(String expectedurl) throws IOException {
		//this function is derived from Verificationclass class
		verifyallurls(expectedurl);
	}
}
